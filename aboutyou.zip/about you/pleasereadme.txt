i know that this album is not worth much
there is only on actual listenable track here (the first one)
but i really tried to express how i felt throughout the time of being with you
that mixed feeling of sweet love and worry that still haunts me to this day
and the constant fear of doing something wrong and losing your respect
you know i worry about you and about us
i cannot help it
i know you have heard all this from me lots of times 
but i really cannot explain how monumental your presence in my life is 
and i am really really thankful about it
i remember the day when i "came out" to you
i still remember how awkward we both felt
i know you did too
it was hell
and i still remember one message 
it still keeps me awake sometimes
just remembering it brings tears to my eyes
for any other human being it may seem like a regular piece of text
not for me though
"i just want to see you happy"
you said that
but for whatever reason i cannot find that message anymore
i know it was there and now it is not
but i cannot help myself but shed a tear when re-reading it
it reminds me of how ignorant i am towards you
i mostly emphasize our dialogues on me
not on you or us
i am not doing it on purpose i swear
and i am trying my best to fight it out of myself
but yet here i am talking about me again
i must be a terrible caretaker
i am really sorry
you would have probably said "it's alright" as you usually do
and leave me with yet another unforgiven action
but i understand
not everything could be forgiven and i know i crossed the line long ago
it's your choice and i am not your parent to control you
in fact no matter how messed up it sounds but i sometimes think of you as of an older brother or something
yeah that must be weird to imagine
but anyways
you dont have to answer me about this
i will understand if you will not like it
it is not meant to be liked
but to be heard and read
i will probably instantly regret sending this to you
as i usually do when sending you anything i produced
i dont want to leave a bad impression on you you know
again
sorry that there is not much
i am empty after these four
and i cannot keep up
i hope you understand
which you probably dont
i just made myself look like a freak again did i
welp maybe i am a freak after all
here i am talking about me again
god damn it

anyway
i guess i have to end this text on something positive

i dont really have anything else to say
other than i really hope that our union will last forever
you know that i fantasize about us a lot
and mostly that is just everyday stuff
like
we cook food together
watch tv together
go shopping together
you calm me down when i am feeling depressed, sitting beside me
and i do the same with you when you are feeling bad
it is really sweet to imagine
and i really with it will one day become a reality
honestly - i want to spend the rest of my life with you
you are probably weirded out again
that is completely reasonable
we are together for not that long by now
plus the age gap
i am probably being very delusional
daydreaming a lot and stuff
who knows
we will see
and on that note i thank you for reading this and i am sorry if you do not like this
as i said above
it will be more than enough for me if you even read through this

also please be sure to either disable anticlipping in AIMP (if you are listening though it)
or play through a different media player
like VLC for example

that should be all that i wanted to say
i mean i could go on for hours about the same topics but i can do it later
i once again thank you and ask for forgiveness if something is wrong